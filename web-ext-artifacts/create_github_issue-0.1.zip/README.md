A work in progress.

Adds a context menu item to your browser. Select some text and hit `Create GitHub Issue` and it will create an issue on a GitHub repo containing the text snippet and a URL back to the source.

Setup is done by clicking on the link in the menu bar:
* You need to provide a repository to create the issue in.
* You need to provide a [Personal Access Token](https://help.github.com/en/articles/creating-a-personal-access-token-for-the-command-line) that can write to that repository.
